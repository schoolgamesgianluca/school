﻿var showAds=false;
